import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class UnitsPage extends StatefulWidget {
  final int chapterId;
  UnitsPage({required this.chapterId});

  @override
  _UnitsPageState createState() => _UnitsPageState();
}

class _UnitsPageState extends State<UnitsPage> {
  List units = [];

  @override
  void initState() {
    super.initState();
    fetchUnits();
  }

  Future<void> fetchUnits() async {
    final response = await http.get(Uri.parse('http://127.0.0.1:8000/api/units/${widget.chapterId}/'));
    if (response.statusCode == 200) {
      setState(() {
        units = json.decode(response.body);
      });
    } else {
      throw Exception('Failed to load units');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('유닛 학습하기'),
      ),
      body: ListView.builder(
        itemCount: units.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(units[index]['title']),
            onTap: () {
              // 학습하기 페이지로 이동하는 코드 추가
            },
          );
        },
      ),
    );
  }
}